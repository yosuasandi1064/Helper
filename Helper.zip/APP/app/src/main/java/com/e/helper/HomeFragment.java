package com.e.helper;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageClickListener;
import com.synnapps.carouselview.ImageListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    Dialog myDialog;
    private int[] mImages= new int[]{
            R.drawable.artt, R.drawable.supirr, R.drawable.bodyguardd, R.drawable.babysitterr
    };

    private String[] mImagesTitle=new String[]{
            "Asisten Rumah Tangga", "Supir", "BodyGuard", "BabySitter"
    };

    RecyclerView recyclerView;
    ArrayList<MainModel> mainModels;
    MainAdapter mainAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        final Context context = inflater.getContext();

        myDialog=new Dialog(context);
        CarouselView carouselView=view.findViewById(R.id.carousel);
        carouselView.setPageCount(mImages.length);
        carouselView.setImageListener(new ImageListener() {
            @Override
            public void setImageForPosition(int position, ImageView imageView) {
                imageView.setImageResource(mImages[position]);
            }
        });

        carouselView.setImageClickListener(new ImageClickListener() {
            @Override
            public void onClick(int position) {
                Toast.makeText(context,mImagesTitle[position], Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView=view.findViewById(R.id.recycler_view);
        Integer[] langLogo={R.drawable.orang,R.drawable.orang,R.drawable.orang,R.drawable.orang
                ,R.drawable.orang,R.drawable.orang,R.drawable.orang,R.drawable.orang};

        String[] langName={"Sumi, 30","Siti, 26","Ijah, 32","Tukiem, 29","Iyem, 31","Munaroh, 25","Sari,35","Ita, 25"};
        mainModels=new ArrayList<>();

        for(int i=0;i<langLogo.length;i++){
            MainModel model=new MainModel(langLogo[i],langName[i]);
            mainModels.add(model);
        }

        LinearLayoutManager layoutManager=new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        mainAdapter=new MainAdapter(context,mainModels);
        recyclerView.setAdapter(mainAdapter);

        return view;
    }

}

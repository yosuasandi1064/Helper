package com.e.helper;

public class UserProfile {
    public String Email;
    public String Name;

    public UserProfile(String userEmail, String userName) {
        this.Email = userEmail;
        this.Name = userName;
    }
}
